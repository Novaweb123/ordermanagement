<?php 


/*
$hostname='173.201.178.161';
$username='stk_Om';
$password='3ecmBM6zmx21qKA';
$db_name = "StockandOrderMgmt";
$main_database = "StockandOrderMgmt";
$server_ip = "173.201.178.161";
*/
/*
$hostname='localhost';
$username='root';
$password='';
$db_name = "stockandmanagement";
$main_database = "stockandmanagement";
$server_ip = "localhost";
*/

$hostname='183.82.62.219';
$username='dbuser';
$password='A@123456';
$db_name = "stockandmanagement";
$main_database = "stockandmanagement";
$server_ip = "183.82.62.21";

?>


